# boronide bot (dont msg me about this)

boronide

clone using:
```sh
git clone --recursive https://github.com/mdo992/boronide-bot.git
```
