local Stk	= Stack;

for Idx = |A|, |B| do
    Stk[Idx]	= nil;
end;